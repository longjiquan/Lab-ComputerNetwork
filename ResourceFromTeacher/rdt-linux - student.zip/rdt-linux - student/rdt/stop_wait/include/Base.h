#ifndef BASE_H
#define BASE_H
#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;


#define DEBUG  1

#endif